// Types for market data
export interface MarketData {
  name: string;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  peRatio: number;
  dividendYield: number;
  high52Week: number;
  low52Week: number;
  lastUpdated: string;
}

export interface IndexData {
  name: string;
  symbol: string;
  value: number;
  change: number;
  changePercent: number;
  ytdReturn: number;
  lastUpdated: string;
}

export interface SectorData {
  name: string;
  weight: number;
  change: number;
}

export interface MarketSummary {
  index: IndexData;
  topGainers: MarketData[];
  topLosers: MarketData[];
  sectors: SectorData[];
  marketStats: {
    totalMarketCap: number;
    totalVolume: number;
    advancers: number;
    decliners: number;
    unchanged: number;
    averagePE: number;
    averageDividendYield: number;
  };
}

// BRVM Stock list
export const BRVM_STOCKS = [
  { symbol: "SNTS", name: "Sonatel", sector: "Télécommunications" },
  { symbol: "SGBC", name: "Société Générale CI", sector: "Finance" },
  { symbol: "ETIT", name: "Ecobank Transnational", sector: "Finance" },
  { symbol: "ONTC", name: "Onatel BF", sector: "Télécommunications" },
  { symbol: "BOAB", name: "BOA Bénin", sector: "Finance" },
  { symbol: "BOAC", name: "BOA Côte d'Ivoire", sector: "Finance" },
  { symbol: "CBIB", name: "CORIS Bank International", sector: "Finance" },
  { symbol: "NSBC", name: "NSIA Banque CI", sector: "Finance" },
  { symbol: "SIBC", name: "SIB", sector: "Finance" },
  { symbol: "PALC", name: "Palm CI", sector: "Agriculture" },
  { symbol: "SCRC", name: "Sucrivoire", sector: "Agriculture" },
  { symbol: "SLBC", name: "Solibra", sector: "Industrie" },
  { symbol: "TTLC", name: "Total CI", sector: "Énergie" },
  { symbol: "NEIC", name: "NEI-CEDA", sector: "Industrie" },
  { symbol: "ORAC", name: "Orange CI", sector: "Télécommunications" },
];

// European stocks (major indices components)
export const EUROPEAN_STOCKS = [
  { symbol: "ASML.AS", name: "ASML Holding", sector: "Technologie" },
  { symbol: "MC.PA", name: "LVMH", sector: "Luxe" },
  { symbol: "SAP.DE", name: "SAP SE", sector: "Technologie" },
  { symbol: "SIE.DE", name: "Siemens", sector: "Industrie" },
  { symbol: "TTE.PA", name: "TotalEnergies", sector: "Énergie" },
  { symbol: "OR.PA", name: "L'Oréal", sector: "Consommation" },
  { symbol: "SAN.MC", name: "Santander", sector: "Finance" },
  { symbol: "NESN.SW", name: "Nestlé", sector: "Consommation" },
  { symbol: "ROG.SW", name: "Roche", sector: "Santé" },
  { symbol: "NOVN.SW", name: "Novartis", sector: "Santé" },
];

// Format currency
export function formatCurrency(value: number, currency: string = "EUR"): string {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

// Format large numbers
export function formatLargeNumber(value: number): string {
  if (value >= 1e12) return `${(value / 1e12).toFixed(2)}T`;
  if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K`;
  return value.toFixed(2);
}

// Format percentage
export function formatPercent(value: number): string {
  const sign = value >= 0 ? "+" : "";
  return `${sign}${value.toFixed(2)}%`;
}
