import { EuropeMarketCard } from "@/components/europe-market-card";
import { BRVMMarketCard } from "@/components/brvm-market-card";
import { ComparisonTable } from "@/components/comparison-table";
import { Header, Footer } from "@/components/layout";
import { TrendingUpIcon, GlobeIcon, BarChart3Icon, ShieldCheckIcon } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-muted/50 to-background py-10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3 text-balance">
            Comparez vos opportunités d&apos;investissement
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6 text-pretty">
            Visualisez en temps réel les différences entre les marchés européens et la Bourse
            Régionale des Valeurs Mobilières d&apos;Afrique de l&apos;Ouest.
          </p>
          <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <TrendingUpIcon className="size-4 text-europe" />
              <span>Données actualisées</span>
            </div>
            <div className="flex items-center gap-2">
              <GlobeIcon className="size-4 text-brvm" />
              <span>2 marchés, 1 vue</span>
            </div>
            <div className="flex items-center gap-2">
              <BarChart3Icon className="size-4 text-success" />
              <span>Analyse comparative</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheckIcon className="size-4 text-muted-foreground" />
              <span>Sources fiables</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Market Cards - Side by Side */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <EuropeMarketCard />
          <BRVMMarketCard />
        </div>

        {/* Comparison Table */}
        <div className="mb-8">
          <ComparisonTable />
        </div>

        {/* Pros and Cons */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Europe Advantages */}
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div
              className="px-5 py-3 border-b border-border"
              style={{
                background:
                  "linear-gradient(135deg, oklch(0.55 0.18 250 / 0.08), oklch(0.55 0.18 250 / 0.02))",
              }}
            >
              <div className="flex items-center gap-2">
                <div className="size-6 rounded bg-europe flex items-center justify-center text-white text-xs font-bold">
                  EU
                </div>
                <span className="font-medium text-sm">Avantages Europe</span>
              </div>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <span className="text-xs font-medium text-success mb-2 block">Points forts</span>
                <ul className="space-y-1.5">
                  {[
                    "Haute liquidité des marchés",
                    "Régulation stricte et transparente (ESMA)",
                    "Diversification sectorielle étendue",
                    "Devise stable (EUR)",
                    "Accès facile via nombreux courtiers",
                    "Information financière abondante",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-success mt-0.5">+</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <span className="text-xs font-medium text-destructive mb-2 block">
                  Points faibles
                </span>
                <ul className="space-y-1.5">
                  {[
                    "Rendements potentiels modérés",
                    "Valorisations élevées (P/E)",
                    "Marché mature, croissance limitée",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-destructive mt-0.5">-</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* BRVM Advantages */}
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div
              className="px-5 py-3 border-b border-border"
              style={{
                background:
                  "linear-gradient(135deg, oklch(0.75 0.15 85 / 0.15), oklch(0.75 0.15 85 / 0.05))",
              }}
            >
              <div className="flex items-center gap-2">
                <div className="size-6 rounded bg-brvm flex items-center justify-center text-brvm-foreground text-xs font-bold">
                  BR
                </div>
                <span className="font-medium text-sm">Avantages BRVM</span>
              </div>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <span className="text-xs font-medium text-success mb-2 block">Points forts</span>
                <ul className="space-y-1.5">
                  {[
                    "Fort potentiel de croissance économique",
                    "Dividendes attractifs (5-8%)",
                    "Valorisations basses (P/E faible)",
                    "Devise FCFA arrimée à l'Euro",
                    "Faible corrélation marchés mondiaux",
                    "Exposition aux économies africaines",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-success mt-0.5">+</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <span className="text-xs font-medium text-destructive mb-2 block">
                  Points faibles
                </span>
                <ul className="space-y-1.5">
                  {[
                    "Liquidité limitée",
                    "Frais de courtage plus élevés",
                    "Information moins accessible",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-destructive mt-0.5">-</span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Key Differences Table */}
        <div className="rounded-xl border border-border bg-card overflow-hidden mb-8">
          <div className="px-5 py-4 border-b border-border bg-muted/30">
            <h3 className="font-semibold">Différences Clés</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-5 py-3 text-sm font-medium text-muted-foreground">
                    Critère
                  </th>
                  <th className="text-left px-5 py-3 text-sm font-medium text-europe">Europe</th>
                  <th className="text-left px-5 py-3 text-sm font-medium text-brvm">BRVM</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b border-border">
                  <td className="px-5 py-3 text-muted-foreground">Investissement minimum</td>
                  <td className="px-5 py-3">~50 EUR</td>
                  <td className="px-5 py-3">~5 000 XOF (~8 EUR)</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="px-5 py-3 text-muted-foreground">Frais de courtage</td>
                  <td className="px-5 py-3">0.1% - 0.5%</td>
                  <td className="px-5 py-3">1% - 2%</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="px-5 py-3 text-muted-foreground">Horaires de trading</td>
                  <td className="px-5 py-3">9h - 17h30 (CET)</td>
                  <td className="px-5 py-3">9h - 15h (GMT)</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="px-5 py-3 text-muted-foreground">Devise</td>
                  <td className="px-5 py-3">EUR</td>
                  <td className="px-5 py-3">XOF (parité fixe 655.957 XOF = 1 EUR)</td>
                </tr>
                <tr className="border-b border-border">
                  <td className="px-5 py-3 text-muted-foreground">Fiscalité dividendes</td>
                  <td className="px-5 py-3">15% - 30%</td>
                  <td className="px-5 py-3">10% - 15%</td>
                </tr>
                <tr>
                  <td className="px-5 py-3 text-muted-foreground">Pays couverts</td>
                  <td className="px-5 py-3">27 pays UE + UK, CH</td>
                  <td className="px-5 py-3">8 pays UEMOA</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Risk Warning */}
        <div className="bg-muted/50 border border-border rounded-xl p-5 text-center">
          <p className="text-sm text-muted-foreground">
            <strong>Avertissement :</strong> Les données présentées sont fournies à titre
            informatif uniquement. L&apos;investissement en bourse comporte des risques de perte
            en capital. Les performances passées ne préjugent pas des performances futures.
            Consultez un conseiller financier avant tout investissement.
          </p>
        </div>
      </main>

      <Footer />
    </div>
  );
}
