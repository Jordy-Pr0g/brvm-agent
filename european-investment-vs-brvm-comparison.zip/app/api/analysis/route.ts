import { NextResponse } from "next/server";

interface AnalysisData {
  marketOverview: {
    europe: {
      sentiment: "bullish" | "bearish" | "neutral";
      trendStrength: number;
      volatilityIndex: number;
      recommendation: string;
      keyEvents: string[];
    };
    brvm: {
      sentiment: "bullish" | "bearish" | "neutral";
      trendStrength: number;
      volatilityIndex: number;
      recommendation: string;
      keyEvents: string[];
    };
  };
  sectorAnalysis: {
    sector: string;
    europePerformance: number;
    brvmPerformance: number;
    outlook: string;
  }[];
  technicalIndicators: {
    market: string;
    rsi: number;
    macd: "bullish" | "bearish" | "neutral";
    movingAverage50: "above" | "below";
    movingAverage200: "above" | "below";
    support: number;
    resistance: number;
  }[];
  economicIndicators: {
    region: string;
    gdpGrowth: number;
    inflation: number;
    interestRate: number;
    unemployment: number;
    pmi: number;
  }[];
  topPicks: {
    market: string;
    symbol: string;
    name: string;
    reason: string;
    targetPrice: number;
    currentPrice: number;
    potentialReturn: number;
  }[];
  riskAssessment: {
    market: string;
    overallRisk: "low" | "medium" | "high";
    factors: { factor: string; impact: "positive" | "negative" | "neutral" }[];
  }[];
}

function generateAnalysisData(): AnalysisData {
  const sentiments: Array<"bullish" | "bearish" | "neutral"> = ["bullish", "bearish", "neutral"];
  
  return {
    marketOverview: {
      europe: {
        sentiment: sentiments[Math.floor(Math.random() * 3)],
        trendStrength: Number((Math.random() * 100).toFixed(1)),
        volatilityIndex: Number((15 + Math.random() * 15).toFixed(1)),
        recommendation: "Maintenir une allocation diversifiée avec surpondération défensive",
        keyEvents: [
          "Décision BCE sur les taux directeurs",
          "Publication résultats T4 grandes capitalisations",
          "Négociations commerciales UE-UK",
          "Données PMI manufacturier zone euro",
        ],
      },
      brvm: {
        sentiment: sentiments[Math.floor(Math.random() * 3)],
        trendStrength: Number((Math.random() * 100).toFixed(1)),
        volatilityIndex: Number((8 + Math.random() * 10).toFixed(1)),
        recommendation: "Privilégier les valeurs de rendement et le secteur bancaire",
        keyEvents: [
          "Saison des dividendes en cours",
          "Introduction en bourse prévue - secteur télécom",
          "Réunion BCEAO politique monétaire",
          "Publication PIB zone UEMOA",
        ],
      },
    },
    sectorAnalysis: [
      { sector: "Finance", europePerformance: Number((Math.random() * 20 - 5).toFixed(2)), brvmPerformance: Number((Math.random() * 25 - 5).toFixed(2)), outlook: "Positif - Hausse des marges d'intérêt" },
      { sector: "Télécommunications", europePerformance: Number((Math.random() * 15 - 5).toFixed(2)), brvmPerformance: Number((Math.random() * 20 - 2).toFixed(2)), outlook: "Stable - Croissance data mobile" },
      { sector: "Énergie", europePerformance: Number((Math.random() * 25 - 10).toFixed(2)), brvmPerformance: Number((Math.random() * 15 - 5).toFixed(2)), outlook: "Volatil - Dépendant prix pétrole" },
      { sector: "Consommation", europePerformance: Number((Math.random() * 12 - 3).toFixed(2)), brvmPerformance: Number((Math.random() * 18 - 2).toFixed(2)), outlook: "Positif - Croissance classe moyenne" },
      { sector: "Industrie", europePerformance: Number((Math.random() * 18 - 8).toFixed(2)), brvmPerformance: Number((Math.random() * 15 - 5).toFixed(2)), outlook: "Prudent - Incertitudes économiques" },
      { sector: "Agriculture", europePerformance: Number((Math.random() * 10 - 5).toFixed(2)), brvmPerformance: Number((Math.random() * 20 - 3).toFixed(2)), outlook: "Positif - Demande croissante" },
    ],
    technicalIndicators: [
      {
        market: "STOXX 600",
        rsi: Number((30 + Math.random() * 40).toFixed(1)),
        macd: sentiments[Math.floor(Math.random() * 3)] as "bullish" | "bearish" | "neutral",
        movingAverage50: Math.random() > 0.5 ? "above" : "below",
        movingAverage200: Math.random() > 0.4 ? "above" : "below",
        support: 495,
        resistance: 535,
      },
      {
        market: "BRVM Composite",
        rsi: Number((35 + Math.random() * 35).toFixed(1)),
        macd: sentiments[Math.floor(Math.random() * 3)] as "bullish" | "bearish" | "neutral",
        movingAverage50: Math.random() > 0.4 ? "above" : "below",
        movingAverage200: Math.random() > 0.5 ? "above" : "below",
        support: 235,
        resistance: 265,
      },
    ],
    economicIndicators: [
      {
        region: "Zone Euro",
        gdpGrowth: Number((0.5 + Math.random() * 2).toFixed(1)),
        inflation: Number((2 + Math.random() * 3).toFixed(1)),
        interestRate: 4.25,
        unemployment: Number((6 + Math.random() * 2).toFixed(1)),
        pmi: Number((48 + Math.random() * 8).toFixed(1)),
      },
      {
        region: "Zone UEMOA",
        gdpGrowth: Number((5 + Math.random() * 2).toFixed(1)),
        inflation: Number((2 + Math.random() * 4).toFixed(1)),
        interestRate: 3.50,
        unemployment: Number((3 + Math.random() * 3).toFixed(1)),
        pmi: Number((50 + Math.random() * 6).toFixed(1)),
      },
    ],
    topPicks: [
      {
        market: "Europe",
        symbol: "ASML.AS",
        name: "ASML Holding",
        reason: "Leader mondial équipements semi-conducteurs, carnet de commandes record",
        targetPrice: 980,
        currentPrice: 890,
        potentialReturn: 10.1,
      },
      {
        market: "Europe",
        symbol: "SAP.DE",
        name: "SAP SE",
        reason: "Transition cloud réussie, croissance récurrente forte",
        targetPrice: 225,
        currentPrice: 195,
        potentialReturn: 15.4,
      },
      {
        market: "BRVM",
        symbol: "SNTS",
        name: "Sonatel",
        reason: "Dividende attractif 7%, croissance mobile money",
        targetPrice: 24000,
        currentPrice: 20500,
        potentialReturn: 17.1,
      },
      {
        market: "BRVM",
        symbol: "CBIB",
        name: "CORIS Bank International",
        reason: "Expansion régionale, valorisation attractive",
        targetPrice: 12500,
        currentPrice: 10200,
        potentialReturn: 22.5,
      },
    ],
    riskAssessment: [
      {
        market: "Europe",
        overallRisk: "medium",
        factors: [
          { factor: "Politique monétaire BCE", impact: "negative" },
          { factor: "Tensions géopolitiques", impact: "negative" },
          { factor: "Innovation technologique", impact: "positive" },
          { factor: "Transition énergétique", impact: "positive" },
          { factor: "Croissance économique modérée", impact: "neutral" },
        ],
      },
      {
        market: "BRVM",
        overallRisk: "medium",
        factors: [
          { factor: "Liquidité limitée", impact: "negative" },
          { factor: "Croissance démographique", impact: "positive" },
          { factor: "Développement infrastructures", impact: "positive" },
          { factor: "Stabilité politique variable", impact: "negative" },
          { factor: "Parité XOF/EUR fixe", impact: "positive" },
        ],
      },
    ],
  };
}

export async function GET() {
  const data = generateAnalysisData();

  return NextResponse.json({
    ...data,
    generatedAt: new Date().toISOString(),
  }, {
    headers: {
      "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
    },
  });
}
