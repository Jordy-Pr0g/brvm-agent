import { NextResponse } from "next/server";
import type { MarketSummary, IndexData, MarketData, SectorData } from "@/lib/market-data";

// Fetch European market data from Yahoo Finance API
async function fetchYahooFinanceData(symbols: string[]): Promise<Record<string, unknown>> {
  try {
    const symbolsString = symbols.join(",");
    const response = await fetch(
      `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbolsString}`,
      {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
        next: { revalidate: 60 }, // Cache for 60 seconds
      }
    );

    if (!response.ok) {
      throw new Error(`Yahoo Finance API error: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching Yahoo Finance data:", error);
    throw error;
  }
}

// Fetch STOXX 600 index data
async function fetchEuropeanIndex(): Promise<IndexData> {
  try {
    const data = await fetchYahooFinanceData(["^STOXX"]);
    const quote = data?.quoteResponse?.result?.[0];

    if (quote) {
      return {
        name: "STOXX Europe 600",
        symbol: "^STOXX",
        value: quote.regularMarketPrice || 0,
        change: quote.regularMarketChange || 0,
        changePercent: quote.regularMarketChangePercent || 0,
        ytdReturn: quote.ytdReturn || ((quote.regularMarketPrice - quote.fiftyTwoWeekLow) / quote.fiftyTwoWeekLow) * 100,
        lastUpdated: new Date().toISOString(),
      };
    }
  } catch (error) {
    console.error("Error fetching European index:", error);
  }

  // Fallback data if API fails
  return {
    name: "STOXX Europe 600",
    symbol: "^STOXX",
    value: 512.45,
    change: 2.34,
    changePercent: 0.46,
    ytdReturn: 8.2,
    lastUpdated: new Date().toISOString(),
  };
}

// Fetch major European stocks
async function fetchEuropeanStocks(): Promise<MarketData[]> {
  const symbols = [
    "ASML.AS", "MC.PA", "SAP.DE", "SIE.DE", "TTE.PA",
    "OR.PA", "BNP.PA", "SAN.PA", "AIR.PA", "DTE.DE"
  ];

  try {
    const data = await fetchYahooFinanceData(symbols);
    const quotes = data?.quoteResponse?.result || [];

    return quotes.map((quote: Record<string, unknown>) => ({
      name: quote.shortName || quote.symbol,
      symbol: quote.symbol,
      price: quote.regularMarketPrice || 0,
      change: quote.regularMarketChange || 0,
      changePercent: quote.regularMarketChangePercent || 0,
      volume: quote.regularMarketVolume || 0,
      marketCap: quote.marketCap || 0,
      peRatio: quote.trailingPE || 0,
      dividendYield: quote.dividendYield || 0,
      high52Week: quote.fiftyTwoWeekHigh || 0,
      low52Week: quote.fiftyTwoWeekLow || 0,
      lastUpdated: new Date().toISOString(),
    }));
  } catch (error) {
    console.error("Error fetching European stocks:", error);
    // Return mock data if API fails
    return generateMockEuropeanStocks();
  }
}

function generateMockEuropeanStocks(): MarketData[] {
  const stocks = [
    { name: "ASML Holding", symbol: "ASML.AS", basePrice: 892.50 },
    { name: "LVMH", symbol: "MC.PA", basePrice: 734.20 },
    { name: "SAP SE", symbol: "SAP.DE", basePrice: 187.45 },
    { name: "Siemens", symbol: "SIE.DE", basePrice: 168.30 },
    { name: "TotalEnergies", symbol: "TTE.PA", basePrice: 62.45 },
    { name: "L'Oréal", symbol: "OR.PA", basePrice: 412.80 },
    { name: "BNP Paribas", symbol: "BNP.PA", basePrice: 65.23 },
    { name: "Sanofi", symbol: "SAN.PA", basePrice: 92.15 },
    { name: "Airbus", symbol: "AIR.PA", basePrice: 142.67 },
    { name: "Deutsche Telekom", symbol: "DTE.DE", basePrice: 24.89 },
  ];

  return stocks.map((stock) => {
    const randomChange = (Math.random() - 0.5) * 4;
    const price = stock.basePrice * (1 + randomChange / 100);
    return {
      name: stock.name,
      symbol: stock.symbol,
      price,
      change: price - stock.basePrice,
      changePercent: randomChange,
      volume: Math.floor(Math.random() * 5000000) + 1000000,
      marketCap: price * (Math.random() * 100 + 50) * 1e9,
      peRatio: Math.random() * 20 + 10,
      dividendYield: Math.random() * 4 + 1,
      high52Week: stock.basePrice * 1.2,
      low52Week: stock.basePrice * 0.8,
      lastUpdated: new Date().toISOString(),
    };
  });
}

// European sectors data
function getEuropeanSectors(): SectorData[] {
  return [
    { name: "Finance", weight: 18.5, change: 0.82 },
    { name: "Industrie", weight: 16.2, change: -0.34 },
    { name: "Santé", weight: 14.8, change: 1.23 },
    { name: "Consommation", weight: 12.4, change: 0.45 },
    { name: "Technologie", weight: 11.9, change: 1.87 },
    { name: "Énergie", weight: 8.7, change: -0.92 },
    { name: "Matériaux", weight: 7.3, change: 0.21 },
    { name: "Utilities", weight: 5.6, change: 0.15 },
    { name: "Télécoms", weight: 4.6, change: -0.28 },
  ];
}

export async function GET() {
  try {
    const [index, stocks] = await Promise.all([
      fetchEuropeanIndex(),
      fetchEuropeanStocks(),
    ]);

    const sortedByChange = [...stocks].sort((a, b) => b.changePercent - a.changePercent);
    const topGainers = sortedByChange.slice(0, 5);
    const topLosers = sortedByChange.slice(-5).reverse();

    const totalMarketCap = stocks.reduce((sum, s) => sum + s.marketCap, 0);
    const totalVolume = stocks.reduce((sum, s) => sum + s.volume, 0);
    const advancers = stocks.filter((s) => s.changePercent > 0).length;
    const decliners = stocks.filter((s) => s.changePercent < 0).length;
    const unchanged = stocks.filter((s) => s.changePercent === 0).length;
    const averagePE = stocks.reduce((sum, s) => sum + s.peRatio, 0) / stocks.length;
    const averageDividendYield = stocks.reduce((sum, s) => sum + s.dividendYield, 0) / stocks.length;

    const summary: MarketSummary = {
      index,
      topGainers,
      topLosers,
      sectors: getEuropeanSectors(),
      marketStats: {
        totalMarketCap,
        totalVolume,
        advancers,
        decliners,
        unchanged,
        averagePE,
        averageDividendYield,
      },
    };

    return NextResponse.json(summary);
  } catch (error) {
    console.error("Error in European market API:", error);
    return NextResponse.json(
      { error: "Failed to fetch European market data" },
      { status: 500 }
    );
  }
}
