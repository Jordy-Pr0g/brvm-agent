import { NextResponse } from "next/server";

// European stocks and ETFs data
const EUROPEAN_STOCKS = [
  { symbol: "ASML.AS", name: "ASML Holding", sector: "Technologie", country: "Pays-Bas", type: "action" },
  { symbol: "MC.PA", name: "LVMH", sector: "Luxe", country: "France", type: "action" },
  { symbol: "SAP.DE", name: "SAP SE", sector: "Technologie", country: "Allemagne", type: "action" },
  { symbol: "SIE.DE", name: "Siemens", sector: "Industrie", country: "Allemagne", type: "action" },
  { symbol: "TTE.PA", name: "TotalEnergies", sector: "Énergie", country: "France", type: "action" },
  { symbol: "OR.PA", name: "L'Oréal", sector: "Consommation", country: "France", type: "action" },
  { symbol: "SAN.MC", name: "Santander", sector: "Finance", country: "Espagne", type: "action" },
  { symbol: "NESN.SW", name: "Nestlé", sector: "Consommation", country: "Suisse", type: "action" },
  { symbol: "ROG.SW", name: "Roche", sector: "Santé", country: "Suisse", type: "action" },
  { symbol: "NOVN.SW", name: "Novartis", sector: "Santé", country: "Suisse", type: "action" },
  { symbol: "AIR.PA", name: "Airbus", sector: "Aéronautique", country: "France", type: "action" },
  { symbol: "BNP.PA", name: "BNP Paribas", sector: "Finance", country: "France", type: "action" },
  { symbol: "DTE.DE", name: "Deutsche Telekom", sector: "Télécommunications", country: "Allemagne", type: "action" },
  { symbol: "ENEL.MI", name: "Enel", sector: "Énergie", country: "Italie", type: "action" },
  { symbol: "IBE.MC", name: "Iberdrola", sector: "Énergie", country: "Espagne", type: "action" },
  { symbol: "ABI.BR", name: "AB InBev", sector: "Consommation", country: "Belgique", type: "action" },
  { symbol: "BAYN.DE", name: "Bayer", sector: "Santé", country: "Allemagne", type: "action" },
  { symbol: "ADS.DE", name: "Adidas", sector: "Consommation", country: "Allemagne", type: "action" },
  { symbol: "PHIA.AS", name: "Philips", sector: "Santé", country: "Pays-Bas", type: "action" },
  { symbol: "IFX.DE", name: "Infineon", sector: "Technologie", country: "Allemagne", type: "action" },
];

const EUROPEAN_ETFS = [
  { symbol: "VEUR.AS", name: "Vanguard FTSE Europe", sector: "Diversifié", country: "Europe", type: "etf", expense: 0.10 },
  { symbol: "IEUR.AS", name: "iShares Core MSCI Europe", sector: "Diversifié", country: "Europe", type: "etf", expense: 0.12 },
  { symbol: "MEUD.PA", name: "Lyxor MSCI Europe", sector: "Diversifié", country: "Europe", type: "etf", expense: 0.25 },
  { symbol: "EXS1.DE", name: "iShares STOXX Europe 600", sector: "Diversifié", country: "Europe", type: "etf", expense: 0.20 },
  { symbol: "DJSC.DE", name: "iShares Euro STOXX Small", sector: "Small Cap", country: "Zone Euro", type: "etf", expense: 0.40 },
  { symbol: "IQQH.DE", name: "iShares Global Clean Energy", sector: "Énergie Verte", country: "Global", type: "etf", expense: 0.65 },
  { symbol: "EQQQ.DE", name: "Invesco EQQQ NASDAQ-100", sector: "Technologie US", country: "USA", type: "etf", expense: 0.30 },
  { symbol: "VWCE.DE", name: "Vanguard FTSE All-World", sector: "Global", country: "Monde", type: "etf", expense: 0.22 },
  { symbol: "IDVY.AS", name: "iShares Euro Dividend", sector: "Dividendes", country: "Zone Euro", type: "etf", expense: 0.40 },
  { symbol: "EXSA.DE", name: "iShares STOXX Europe 50", sector: "Large Cap", country: "Europe", type: "etf", expense: 0.35 },
  { symbol: "DBXD.DE", name: "Xtrackers DAX", sector: "Allemagne", country: "Allemagne", type: "etf", expense: 0.09 },
  { symbol: "DBXF.DE", name: "Xtrackers CAC 40", sector: "France", country: "France", type: "etf", expense: 0.20 },
];

function generateRealisticPrice(basePrice: number, volatility: number = 0.02): number {
  const change = (Math.random() - 0.5) * 2 * volatility;
  return basePrice * (1 + change);
}

function generateStockData(stock: typeof EUROPEAN_STOCKS[0], isETF: boolean = false) {
  const basePrices: Record<string, number> = {
    "ASML.AS": 890, "MC.PA": 720, "SAP.DE": 195, "SIE.DE": 175, "TTE.PA": 58,
    "OR.PA": 410, "SAN.MC": 4.8, "NESN.SW": 95, "ROG.SW": 280, "NOVN.SW": 92,
    "AIR.PA": 155, "BNP.PA": 62, "DTE.DE": 26, "ENEL.MI": 6.5, "IBE.MC": 12.5,
    "ABI.BR": 52, "BAYN.DE": 28, "ADS.DE": 220, "PHIA.AS": 25, "IFX.DE": 32,
    "VEUR.AS": 35, "IEUR.AS": 32, "MEUD.PA": 145, "EXS1.DE": 48, "DJSC.DE": 42,
    "IQQH.DE": 8.5, "EQQQ.DE": 385, "VWCE.DE": 120, "IDVY.AS": 22, "EXSA.DE": 45,
    "DBXD.DE": 165, "DBXF.DE": 82,
  };

  const basePrice = basePrices[stock.symbol] || 50;
  const price = generateRealisticPrice(basePrice);
  const changePercent = (Math.random() - 0.48) * 6;
  const change = price * (changePercent / 100);
  const volume = Math.floor(Math.random() * 5000000) + 100000;
  const marketCap = price * (Math.floor(Math.random() * 500) + 50) * 1000000;

  return {
    ...stock,
    price: Number(price.toFixed(2)),
    change: Number(change.toFixed(2)),
    changePercent: Number(changePercent.toFixed(2)),
    volume,
    marketCap,
    high52Week: Number((price * 1.25).toFixed(2)),
    low52Week: Number((price * 0.75).toFixed(2)),
    peRatio: isETF ? null : Number((Math.random() * 25 + 8).toFixed(2)),
    dividendYield: Number((Math.random() * 4 + 0.5).toFixed(2)),
    lastUpdated: new Date().toISOString(),
  };
}

export async function GET() {
  const stocks = EUROPEAN_STOCKS.map((s) => generateStockData(s, false));
  const etfs = EUROPEAN_ETFS.map((s) => ({
    ...generateStockData(s, true),
    expense: (s as typeof EUROPEAN_ETFS[0]).expense,
  }));

  return NextResponse.json({
    stocks,
    etfs,
    lastUpdated: new Date().toISOString(),
  }, {
    headers: {
      "Cache-Control": "public, s-maxage=30, stale-while-revalidate=60",
    },
  });
}
