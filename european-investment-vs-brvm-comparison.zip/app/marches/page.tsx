"use client";

import { useState } from "react";
import useSWR from "swr";
import { Header, Footer } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ArrowUpIcon,
  ArrowDownIcon,
  SearchIcon,
  RefreshCwIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  FilterIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

function formatCurrency(value: number, currency: string = "EUR"): string {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency,
    minimumFractionDigits: currency === "XOF" ? 0 : 2,
    maximumFractionDigits: currency === "XOF" ? 0 : 2,
  }).format(value);
}

function formatLargeNumber(value: number): string {
  if (value >= 1e12) return `${(value / 1e12).toFixed(2)}T`;
  if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(2)}K`;
  return value.toFixed(0);
}

interface Stock {
  symbol: string;
  name: string;
  sector: string;
  country: string;
  type: string;
  price: number;
  priceEUR?: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  marketCapEUR?: number;
  high52Week: number;
  low52Week: number;
  peRatio: number | null;
  dividendYield: number;
  expense?: number;
}

function StockTable({
  stocks,
  currency = "EUR",
  showExpense = false,
}: {
  stocks: Stock[];
  currency?: string;
  showExpense?: boolean;
}) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="min-w-[200px]">Titre</TableHead>
            <TableHead className="text-right">Prix</TableHead>
            <TableHead className="text-right">Variation</TableHead>
            <TableHead className="text-right hidden md:table-cell">Volume</TableHead>
            <TableHead className="text-right hidden lg:table-cell">Cap. Marché</TableHead>
            <TableHead className="text-right hidden lg:table-cell">P/E</TableHead>
            <TableHead className="text-right hidden md:table-cell">Div. Yield</TableHead>
            {showExpense && <TableHead className="text-right hidden md:table-cell">Frais</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {stocks.map((stock) => (
            <TableRow key={stock.symbol} className="hover:bg-muted/50 cursor-pointer">
              <TableCell>
                <div className="flex flex-col">
                  <span className="font-medium">{stock.symbol}</span>
                  <span className="text-xs text-muted-foreground truncate max-w-[180px]">
                    {stock.name}
                  </span>
                  <div className="flex gap-1 mt-1">
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                      {stock.sector}
                    </Badge>
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                      {stock.country}
                    </Badge>
                  </div>
                </div>
              </TableCell>
              <TableCell className="text-right font-mono">
                <div className="flex flex-col items-end">
                  <span>{formatCurrency(stock.price, currency)}</span>
                  {stock.priceEUR && currency === "XOF" && (
                    <span className="text-[10px] text-muted-foreground">
                      {formatCurrency(stock.priceEUR, "EUR")}
                    </span>
                  )}
                </div>
              </TableCell>
              <TableCell className="text-right">
                <div
                  className={cn(
                    "flex items-center justify-end gap-1 font-mono text-sm",
                    stock.changePercent >= 0 ? "text-success" : "text-destructive"
                  )}
                >
                  {stock.changePercent >= 0 ? (
                    <ArrowUpIcon className="size-3" />
                  ) : (
                    <ArrowDownIcon className="size-3" />
                  )}
                  <span>
                    {stock.changePercent >= 0 ? "+" : ""}
                    {stock.changePercent.toFixed(2)}%
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-right hidden md:table-cell font-mono text-muted-foreground">
                {formatLargeNumber(stock.volume)}
              </TableCell>
              <TableCell className="text-right hidden lg:table-cell font-mono text-muted-foreground">
                {formatLargeNumber(stock.marketCapEUR || stock.marketCap)}
              </TableCell>
              <TableCell className="text-right hidden lg:table-cell font-mono text-muted-foreground">
                {stock.peRatio ? stock.peRatio.toFixed(1) : "-"}
              </TableCell>
              <TableCell className="text-right hidden md:table-cell font-mono text-muted-foreground">
                {stock.dividendYield.toFixed(2)}%
              </TableCell>
              {showExpense && (
                <TableCell className="text-right hidden md:table-cell font-mono text-muted-foreground">
                  {stock.expense ? `${stock.expense.toFixed(2)}%` : "-"}
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function MarketStats({
  gainers,
  losers,
  currency = "EUR",
}: {
  gainers: Stock[];
  losers: Stock[];
  currency?: string;
}) {
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2 text-success">
            <TrendingUpIcon className="size-4" />
            Top Hausses
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {gainers.slice(0, 5).map((stock) => (
            <div
              key={stock.symbol}
              className="flex items-center justify-between text-sm"
            >
              <div>
                <span className="font-medium">{stock.symbol}</span>
                <span className="text-muted-foreground ml-2 text-xs">
                  {stock.name.length > 15 ? stock.name.slice(0, 15) + "..." : stock.name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono">
                  {formatCurrency(stock.price, currency)}
                </span>
                <Badge variant="default" className="bg-success text-success-foreground text-xs">
                  +{stock.changePercent.toFixed(2)}%
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2 text-destructive">
            <TrendingDownIcon className="size-4" />
            Top Baisses
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {losers.slice(0, 5).map((stock) => (
            <div
              key={stock.symbol}
              className="flex items-center justify-between text-sm"
            >
              <div>
                <span className="font-medium">{stock.symbol}</span>
                <span className="text-muted-foreground ml-2 text-xs">
                  {stock.name.length > 15 ? stock.name.slice(0, 15) + "..." : stock.name}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono">
                  {formatCurrency(stock.price, currency)}
                </span>
                <Badge variant="destructive" className="text-xs">
                  {stock.changePercent.toFixed(2)}%
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

export default function MarchesPage() {
  const [europeSearch, setEuropeSearch] = useState("");
  const [brvmSearch, setBrvmSearch] = useState("");
  const [europeSector, setEuropeSector] = useState("all");
  const [brvmSector, setBrvmSector] = useState("all");

  const { data: europeData, isLoading: europeLoading, mutate: refreshEurope } = useSWR(
    "/api/markets/europe/stocks",
    fetcher,
    { refreshInterval: 60000 }
  );

  const { data: brvmData, isLoading: brvmLoading, mutate: refreshBrvm } = useSWR(
    "/api/markets/brvm/stocks",
    fetcher,
    { refreshInterval: 60000 }
  );

  const europeSectors = europeData?.stocks
    ? [...new Set(europeData.stocks.map((s: Stock) => s.sector))]
    : [];

  const brvmSectors = brvmData?.stocks
    ? [...new Set(brvmData.stocks.map((s: Stock) => s.sector))]
    : [];

  const filteredEuropeStocks = europeData?.stocks?.filter((s: Stock) => {
    const matchesSearch =
      s.name.toLowerCase().includes(europeSearch.toLowerCase()) ||
      s.symbol.toLowerCase().includes(europeSearch.toLowerCase());
    const matchesSector = europeSector === "all" || s.sector === europeSector;
    return matchesSearch && matchesSector;
  }) || [];

  const filteredBrvmStocks = brvmData?.stocks?.filter((s: Stock) => {
    const matchesSearch =
      s.name.toLowerCase().includes(brvmSearch.toLowerCase()) ||
      s.symbol.toLowerCase().includes(brvmSearch.toLowerCase());
    const matchesSector = brvmSector === "all" || s.sector === brvmSector;
    return matchesSearch && matchesSector;
  }) || [];

  const europeGainers = [...(europeData?.stocks || [])].sort(
    (a: Stock, b: Stock) => b.changePercent - a.changePercent
  );
  const europeLosers = [...(europeData?.stocks || [])].sort(
    (a: Stock, b: Stock) => a.changePercent - b.changePercent
  );

  const brvmGainers = [...(brvmData?.stocks || [])].sort(
    (a: Stock, b: Stock) => b.changePercent - a.changePercent
  );
  const brvmLosers = [...(brvmData?.stocks || [])].sort(
    (a: Stock, b: Stock) => a.changePercent - b.changePercent
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            Marchés
          </h1>
          <p className="text-muted-foreground">
            Consultez les actions et ETF des marchés européens et de la BRVM en temps réel.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Europe Section */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="size-8 rounded bg-europe flex items-center justify-center text-white text-xs font-bold">
                  EU
                </div>
                <div>
                  <h2 className="font-semibold">Marchés Européens</h2>
                  <p className="text-xs text-muted-foreground">
                    {europeData?.stocks?.length || 0} actions, {europeData?.etfs?.length || 0} ETFs
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => refreshEurope()}
                disabled={europeLoading}
              >
                <RefreshCwIcon className={cn("size-4 mr-1", europeLoading && "animate-spin")} />
                Actualiser
              </Button>
            </div>

            <Tabs defaultValue="actions" className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="actions" className="flex-1">
                  Actions
                </TabsTrigger>
                <TabsTrigger value="etfs" className="flex-1">
                  ETFs
                </TabsTrigger>
                <TabsTrigger value="stats" className="flex-1">
                  Stats
                </TabsTrigger>
              </TabsList>

              <div className="mt-4 flex gap-2">
                <div className="relative flex-1">
                  <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    placeholder="Rechercher..."
                    value={europeSearch}
                    onChange={(e) => setEuropeSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={europeSector} onValueChange={setEuropeSector}>
                  <SelectTrigger className="w-[140px]">
                    <FilterIcon className="size-4 mr-1" />
                    <SelectValue placeholder="Secteur" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    {europeSectors.map((sector: string) => (
                      <SelectItem key={sector} value={sector}>
                        {sector}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <TabsContent value="actions" className="mt-4">
                <Card>
                  <CardContent className="p-0">
                    {europeLoading ? (
                      <div className="p-8 text-center text-muted-foreground">
                        Chargement...
                      </div>
                    ) : (
                      <StockTable stocks={filteredEuropeStocks} currency="EUR" />
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="etfs" className="mt-4">
                <Card>
                  <CardContent className="p-0">
                    {europeLoading ? (
                      <div className="p-8 text-center text-muted-foreground">
                        Chargement...
                      </div>
                    ) : (
                      <StockTable
                        stocks={europeData?.etfs || []}
                        currency="EUR"
                        showExpense
                      />
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="stats" className="mt-4">
                <MarketStats
                  gainers={europeGainers}
                  losers={europeLosers}
                  currency="EUR"
                />
              </TabsContent>
            </Tabs>
          </div>

          {/* BRVM Section */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="size-8 rounded bg-brvm flex items-center justify-center text-brvm-foreground text-xs font-bold">
                  BR
                </div>
                <div>
                  <h2 className="font-semibold">BRVM</h2>
                  <p className="text-xs text-muted-foreground">
                    {brvmData?.stocks?.length || 0} actions, {brvmData?.opcvm?.length || 0} OPCVM
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => refreshBrvm()}
                disabled={brvmLoading}
              >
                <RefreshCwIcon className={cn("size-4 mr-1", brvmLoading && "animate-spin")} />
                Actualiser
              </Button>
            </div>

            <Tabs defaultValue="actions" className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="actions" className="flex-1">
                  Actions
                </TabsTrigger>
                <TabsTrigger value="opcvm" className="flex-1">
                  OPCVM
                </TabsTrigger>
                <TabsTrigger value="stats" className="flex-1">
                  Stats
                </TabsTrigger>
              </TabsList>

              <div className="mt-4 flex gap-2">
                <div className="relative flex-1">
                  <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    placeholder="Rechercher..."
                    value={brvmSearch}
                    onChange={(e) => setBrvmSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={brvmSector} onValueChange={setBrvmSector}>
                  <SelectTrigger className="w-[140px]">
                    <FilterIcon className="size-4 mr-1" />
                    <SelectValue placeholder="Secteur" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    {brvmSectors.map((sector: string) => (
                      <SelectItem key={sector} value={sector}>
                        {sector}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <TabsContent value="actions" className="mt-4">
                <Card>
                  <CardContent className="p-0">
                    {brvmLoading ? (
                      <div className="p-8 text-center text-muted-foreground">
                        Chargement...
                      </div>
                    ) : (
                      <StockTable stocks={filteredBrvmStocks} currency="XOF" />
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="opcvm" className="mt-4">
                <Card>
                  <CardContent className="p-0">
                    {brvmLoading ? (
                      <div className="p-8 text-center text-muted-foreground">
                        Chargement...
                      </div>
                    ) : (
                      <StockTable
                        stocks={brvmData?.opcvm || []}
                        currency="XOF"
                        showExpense
                      />
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="stats" className="mt-4">
                <MarketStats
                  gainers={brvmGainers}
                  losers={brvmLosers}
                  currency="XOF"
                />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
