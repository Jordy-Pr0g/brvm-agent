"use client";

import useSWR from "swr";
import { Header, Footer } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  RefreshCwIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  MinusIcon,
  AlertTriangleIcon,
  CheckCircleIcon,
  XCircleIcon,
  TargetIcon,
  BarChart3Icon,
  ActivityIcon,
  GlobeIcon,
  ArrowUpIcon,
  ArrowDownIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
} from "recharts";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

function SentimentBadge({ sentiment }: { sentiment: "bullish" | "bearish" | "neutral" }) {
  const config = {
    bullish: { label: "Haussier", icon: TrendingUpIcon, className: "bg-success/10 text-success" },
    bearish: { label: "Baissier", icon: TrendingDownIcon, className: "bg-destructive/10 text-destructive" },
    neutral: { label: "Neutre", icon: MinusIcon, className: "bg-muted text-muted-foreground" },
  };

  const { label, icon: Icon, className } = config[sentiment];

  return (
    <Badge variant="outline" className={cn("gap-1", className)}>
      <Icon className="size-3" />
      {label}
    </Badge>
  );
}

function RiskBadge({ risk }: { risk: "low" | "medium" | "high" }) {
  const config = {
    low: { label: "Faible", className: "bg-success/10 text-success" },
    medium: { label: "Modéré", className: "bg-warning/10 text-warning" },
    high: { label: "Élevé", className: "bg-destructive/10 text-destructive" },
  };

  const { label, className } = config[risk];

  return (
    <Badge variant="outline" className={className}>
      {label}
    </Badge>
  );
}

function ImpactIcon({ impact }: { impact: "positive" | "negative" | "neutral" }) {
  if (impact === "positive") return <CheckCircleIcon className="size-4 text-success" />;
  if (impact === "negative") return <XCircleIcon className="size-4 text-destructive" />;
  return <MinusIcon className="size-4 text-muted-foreground" />;
}

export default function AnalysesPage() {
  const { data, isLoading, mutate: refresh } = useSWR("/api/analysis", fetcher, {
    refreshInterval: 300000, // 5 minutes
  });

  const sectorChartData = data?.sectorAnalysis?.map((s: {
    sector: string;
    europePerformance: number;
    brvmPerformance: number;
  }) => ({
    sector: s.sector,
    Europe: s.europePerformance,
    BRVM: s.brvmPerformance,
  })) || [];

  const radarData = [
    { subject: "Liquidité", Europe: 90, BRVM: 35 },
    { subject: "Rendement", Europe: 55, BRVM: 75 },
    { subject: "Croissance", Europe: 45, BRVM: 80 },
    { subject: "Stabilité", Europe: 85, BRVM: 55 },
    { subject: "Accessibilité", Europe: 95, BRVM: 50 },
    { subject: "Dividendes", Europe: 50, BRVM: 85 },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              Analyses
            </h1>
            <p className="text-muted-foreground">
              Analyses comparatives et indicateurs techniques des deux marchés.
            </p>
          </div>
          <Button variant="outline" onClick={() => refresh()} disabled={isLoading}>
            <RefreshCwIcon className={cn("size-4 mr-2", isLoading && "animate-spin")} />
            Actualiser
          </Button>
        </div>

        {isLoading ? (
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="h-48" />
              </Card>
            ))}
          </div>
        ) : (
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="w-full max-w-xl">
              <TabsTrigger value="overview" className="flex-1">
                Vue d&apos;ensemble
              </TabsTrigger>
              <TabsTrigger value="sectors" className="flex-1">
                Secteurs
              </TabsTrigger>
              <TabsTrigger value="technical" className="flex-1">
                Technique
              </TabsTrigger>
              <TabsTrigger value="picks" className="flex-1">
                Recommandations
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Market Overview Cards */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Europe Overview */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="size-8 rounded bg-europe flex items-center justify-center text-white text-xs font-bold">
                          EU
                        </div>
                        <div>
                          <CardTitle className="text-lg">Europe</CardTitle>
                          <CardDescription>STOXX 600</CardDescription>
                        </div>
                      </div>
                      <SentimentBadge sentiment={data?.marketOverview?.europe?.sentiment || "neutral"} />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Force de tendance</span>
                        <span className="font-medium">
                          {data?.marketOverview?.europe?.trendStrength?.toFixed(0)}%
                        </span>
                      </div>
                      <Progress value={data?.marketOverview?.europe?.trendStrength || 0} />
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Indice de volatilité</span>
                      <span className="font-medium">
                        {data?.marketOverview?.europe?.volatilityIndex?.toFixed(1)}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        {data?.marketOverview?.europe?.recommendation}
                      </p>
                    </div>
                    <div className="pt-2">
                      <p className="text-xs font-medium text-muted-foreground mb-2">
                        Événements clés :
                      </p>
                      <ul className="space-y-1">
                        {data?.marketOverview?.europe?.keyEvents?.slice(0, 3).map((event: string, i: number) => (
                          <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                            <span className="text-europe mt-0.5">•</span>
                            {event}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>

                {/* BRVM Overview */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="size-8 rounded bg-brvm flex items-center justify-center text-brvm-foreground text-xs font-bold">
                          BR
                        </div>
                        <div>
                          <CardTitle className="text-lg">BRVM</CardTitle>
                          <CardDescription>Composite</CardDescription>
                        </div>
                      </div>
                      <SentimentBadge sentiment={data?.marketOverview?.brvm?.sentiment || "neutral"} />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Force de tendance</span>
                        <span className="font-medium">
                          {data?.marketOverview?.brvm?.trendStrength?.toFixed(0)}%
                        </span>
                      </div>
                      <Progress value={data?.marketOverview?.brvm?.trendStrength || 0} className="[&>div]:bg-brvm" />
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Indice de volatilité</span>
                      <span className="font-medium">
                        {data?.marketOverview?.brvm?.volatilityIndex?.toFixed(1)}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-border">
                      <p className="text-sm text-muted-foreground">
                        {data?.marketOverview?.brvm?.recommendation}
                      </p>
                    </div>
                    <div className="pt-2">
                      <p className="text-xs font-medium text-muted-foreground mb-2">
                        Événements clés :
                      </p>
                      <ul className="space-y-1">
                        {data?.marketOverview?.brvm?.keyEvents?.slice(0, 3).map((event: string, i: number) => (
                          <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                            <span className="text-brvm mt-0.5">•</span>
                            {event}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Economic Indicators */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GlobeIcon className="size-5" />
                    Indicateurs Économiques
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 text-sm font-medium text-muted-foreground">
                            Indicateur
                          </th>
                          <th className="text-right py-3 text-sm font-medium text-europe">
                            Zone Euro
                          </th>
                          <th className="text-right py-3 text-sm font-medium text-brvm">
                            Zone UEMOA
                          </th>
                        </tr>
                      </thead>
                      <tbody className="text-sm">
                        <tr className="border-b border-border">
                          <td className="py-3 text-muted-foreground">Croissance PIB</td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[0]?.gdpGrowth}%
                          </td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[1]?.gdpGrowth}%
                          </td>
                        </tr>
                        <tr className="border-b border-border">
                          <td className="py-3 text-muted-foreground">Inflation</td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[0]?.inflation}%
                          </td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[1]?.inflation}%
                          </td>
                        </tr>
                        <tr className="border-b border-border">
                          <td className="py-3 text-muted-foreground">Taux directeur</td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[0]?.interestRate}%
                          </td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[1]?.interestRate}%
                          </td>
                        </tr>
                        <tr className="border-b border-border">
                          <td className="py-3 text-muted-foreground">Chômage</td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[0]?.unemployment}%
                          </td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[1]?.unemployment}%
                          </td>
                        </tr>
                        <tr>
                          <td className="py-3 text-muted-foreground">PMI Manufacturier</td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[0]?.pmi}
                          </td>
                          <td className="py-3 text-right font-mono">
                            {data?.economicIndicators?.[1]?.pmi}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Radar Comparison */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3Icon className="size-5" />
                    Comparaison Multidimensionnelle
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData}>
                        <PolarGrid strokeDasharray="3 3" />
                        <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12 }} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
                        <Radar
                          name="Europe"
                          dataKey="Europe"
                          stroke="oklch(0.55 0.18 250)"
                          fill="oklch(0.55 0.18 250)"
                          fillOpacity={0.3}
                        />
                        <Radar
                          name="BRVM"
                          dataKey="BRVM"
                          stroke="oklch(0.75 0.15 85)"
                          fill="oklch(0.75 0.15 85)"
                          fillOpacity={0.3}
                        />
                        <Legend />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Assessment */}
              <div className="grid md:grid-cols-2 gap-6">
                {data?.riskAssessment?.map((assessment: {
                  market: string;
                  overallRisk: "low" | "medium" | "high";
                  factors: { factor: string; impact: "positive" | "negative" | "neutral" }[];
                }) => (
                  <Card key={assessment.market}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2">
                          <AlertTriangleIcon className="size-5" />
                          Risques {assessment.market}
                        </CardTitle>
                        <RiskBadge risk={assessment.overallRisk} />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {assessment.factors.map((factor: { factor: string; impact: "positive" | "negative" | "neutral" }, i: number) => (
                          <li key={i} className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">{factor.factor}</span>
                            <ImpactIcon impact={factor.impact} />
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Sectors Tab */}
            <TabsContent value="sectors" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Sectorielle Comparée</CardTitle>
                  <CardDescription>
                    Variation depuis le début de l&apos;année par secteur
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={sectorChartData} layout="vertical">
                        <XAxis type="number" tickFormatter={(v) => `${v}%`} />
                        <YAxis type="category" dataKey="sector" width={100} tick={{ fontSize: 12 }} />
                        <Tooltip
                          formatter={(value: number) => [`${value.toFixed(2)}%`, ""]}
                          contentStyle={{
                            backgroundColor: "oklch(0.15 0.01 260)",
                            border: "1px solid oklch(0.25 0.01 260)",
                            borderRadius: "8px",
                          }}
                        />
                        <Legend />
                        <Bar dataKey="Europe" fill="oklch(0.55 0.18 250)" radius={[0, 4, 4, 0]} />
                        <Bar dataKey="BRVM" fill="oklch(0.75 0.15 85)" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4">
                {data?.sectorAnalysis?.map((sector: {
                  sector: string;
                  europePerformance: number;
                  brvmPerformance: number;
                  outlook: string;
                }) => (
                  <Card key={sector.sector}>
                    <CardContent className="py-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">{sector.sector}</h3>
                          <p className="text-sm text-muted-foreground">{sector.outlook}</p>
                        </div>
                        <div className="flex gap-4 text-sm">
                          <div className="text-right">
                            <p className="text-muted-foreground">Europe</p>
                            <p className={cn(
                              "font-mono font-medium",
                              sector.europePerformance >= 0 ? "text-success" : "text-destructive"
                            )}>
                              {sector.europePerformance >= 0 ? "+" : ""}
                              {sector.europePerformance}%
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-muted-foreground">BRVM</p>
                            <p className={cn(
                              "font-mono font-medium",
                              sector.brvmPerformance >= 0 ? "text-success" : "text-destructive"
                            )}>
                              {sector.brvmPerformance >= 0 ? "+" : ""}
                              {sector.brvmPerformance}%
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Technical Tab */}
            <TabsContent value="technical" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {data?.technicalIndicators?.map((indicator: {
                  market: string;
                  rsi: number;
                  macd: "bullish" | "bearish" | "neutral";
                  movingAverage50: "above" | "below";
                  movingAverage200: "above" | "below";
                  support: number;
                  resistance: number;
                }) => (
                  <Card key={indicator.market}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <ActivityIcon className="size-5" />
                        {indicator.market}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* RSI */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">RSI (14)</span>
                          <span className={cn(
                            "font-mono font-medium",
                            indicator.rsi > 70 ? "text-destructive" :
                            indicator.rsi < 30 ? "text-success" : "text-foreground"
                          )}>
                            {indicator.rsi}
                          </span>
                        </div>
                        <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className={cn(
                              "absolute h-full rounded-full",
                              indicator.rsi > 70 ? "bg-destructive" :
                              indicator.rsi < 30 ? "bg-success" : "bg-primary"
                            )}
                            style={{ width: `${indicator.rsi}%` }}
                          />
                          <div className="absolute top-0 bottom-0 left-[30%] w-px bg-foreground/20" />
                          <div className="absolute top-0 bottom-0 left-[70%] w-px bg-foreground/20" />
                        </div>
                        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                          <span>Survendu</span>
                          <span>Neutre</span>
                          <span>Suracheté</span>
                        </div>
                      </div>

                      {/* MACD */}
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">MACD</span>
                        <SentimentBadge sentiment={indicator.macd} />
                      </div>

                      {/* Moving Averages */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">MM 50</span>
                          <Badge variant="outline" className={cn(
                            indicator.movingAverage50 === "above"
                              ? "bg-success/10 text-success"
                              : "bg-destructive/10 text-destructive"
                          )}>
                            {indicator.movingAverage50 === "above" ? (
                              <ArrowUpIcon className="size-3 mr-1" />
                            ) : (
                              <ArrowDownIcon className="size-3 mr-1" />
                            )}
                            {indicator.movingAverage50 === "above" ? "Au-dessus" : "En-dessous"}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">MM 200</span>
                          <Badge variant="outline" className={cn(
                            indicator.movingAverage200 === "above"
                              ? "bg-success/10 text-success"
                              : "bg-destructive/10 text-destructive"
                          )}>
                            {indicator.movingAverage200 === "above" ? (
                              <ArrowUpIcon className="size-3 mr-1" />
                            ) : (
                              <ArrowDownIcon className="size-3 mr-1" />
                            )}
                            {indicator.movingAverage200 === "above" ? "Au-dessus" : "En-dessous"}
                          </Badge>
                        </div>
                      </div>

                      {/* Support/Resistance */}
                      <div className="pt-2 border-t border-border">
                        <div className="flex justify-between text-sm">
                          <div>
                            <span className="text-muted-foreground">Support</span>
                            <p className="font-mono font-medium text-success">{indicator.support}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-muted-foreground">Résistance</span>
                            <p className="font-mono font-medium text-destructive">{indicator.resistance}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Picks Tab */}
            <TabsContent value="picks" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TargetIcon className="size-5" />
                    Valeurs Recommandées
                  </CardTitle>
                  <CardDescription>
                    Sélection basée sur l&apos;analyse fondamentale et technique
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    {data?.topPicks?.map((pick: {
                      market: string;
                      symbol: string;
                      name: string;
                      reason: string;
                      targetPrice: number;
                      currentPrice: number;
                      potentialReturn: number;
                    }) => (
                      <div
                        key={pick.symbol}
                        className="flex items-start gap-4 p-4 rounded-lg border border-border bg-card hover:bg-muted/50 transition-colors"
                      >
                        <div className={cn(
                          "size-10 rounded flex items-center justify-center text-xs font-bold shrink-0",
                          pick.market === "Europe"
                            ? "bg-europe text-white"
                            : "bg-brvm text-brvm-foreground"
                        )}>
                          {pick.market === "Europe" ? "EU" : "BR"}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold">{pick.symbol}</span>
                            <span className="text-muted-foreground text-sm">{pick.name}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">{pick.reason}</p>
                          <div className="flex flex-wrap gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Prix actuel:</span>{" "}
                              <span className="font-mono">
                                {pick.market === "Europe"
                                  ? `${pick.currentPrice.toFixed(2)} €`
                                  : `${pick.currentPrice.toLocaleString()} XOF`}
                              </span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Objectif:</span>{" "}
                              <span className="font-mono">
                                {pick.market === "Europe"
                                  ? `${pick.targetPrice.toFixed(2)} €`
                                  : `${pick.targetPrice.toLocaleString()} XOF`}
                              </span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Potentiel:</span>{" "}
                              <span className="font-mono text-success">+{pick.potentialReturn}%</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="bg-muted/50 border border-border rounded-xl p-5 text-center">
                <p className="text-sm text-muted-foreground">
                  <strong>Avertissement :</strong> Ces recommandations sont fournies à titre
                  informatif uniquement et ne constituent pas un conseil en investissement.
                  Effectuez vos propres recherches avant tout investissement.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </main>

      <Footer />
    </div>
  );
}
