"use client";

import { ArrowUpIcon, ArrowDownIcon, RefreshCwIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useEuropeanMarket } from "@/hooks/use-market-data";
import { formatLargeNumber, formatPercent } from "@/lib/market-data";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

export function EuropeMarketCard() {
  const { data, isLoading, isError, refresh } = useEuropeanMarket();

  if (isError) {
    return (
      <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <p className="text-destructive mb-4">Erreur de chargement</p>
          <Button onClick={() => refresh()} variant="outline" size="sm">
            <RefreshCwIcon className="mr-2 h-4 w-4" />
            Réessayer
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white overflow-hidden">
      <CardHeader className="bg-blue-600 text-white pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20">
              <span className="text-xl">🇪🇺</span>
            </div>
            <div>
              <CardTitle className="text-xl">Investissement Europe</CardTitle>
              <p className="text-blue-100 text-sm">STOXX Europe 600</p>
            </div>
          </div>
          <Button
            onClick={() => refresh()}
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            disabled={isLoading}
          >
            <RefreshCwIcon className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="pt-6 space-y-6">
        {/* Index Value */}
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-32" />
            <Skeleton className="h-6 w-24" />
          </div>
        ) : (
          <div>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-bold text-foreground">
                {data?.index.value.toFixed(2)}
              </span>
              <div
                className={`flex items-center gap-1 text-lg font-semibold ${
                  (data?.index.changePercent || 0) >= 0
                    ? "text-emerald-600"
                    : "text-red-600"
                }`}
              >
                {(data?.index.changePercent || 0) >= 0 ? (
                  <ArrowUpIcon className="h-5 w-5" />
                ) : (
                  <ArrowDownIcon className="h-5 w-5" />
                )}
                {formatPercent(data?.index.changePercent || 0)}
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              Variation: {data?.index.change.toFixed(2)} pts | YTD:{" "}
              {formatPercent(data?.index.ytdReturn || 0)}
            </p>
          </div>
        )}

        {/* Market Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          {isLoading ? (
            <>
              <Skeleton className="h-20" />
              <Skeleton className="h-20" />
              <Skeleton className="h-20" />
              <Skeleton className="h-20" />
            </>
          ) : (
            <>
              <StatCard
                label="Capitalisation"
                value={`€${formatLargeNumber(data?.marketStats.totalMarketCap || 0)}`}
                color="blue"
              />
              <StatCard
                label="P/E Moyen"
                value={(data?.marketStats.averagePE || 0).toFixed(1)}
                color="blue"
              />
              <StatCard
                label="Rendement Div."
                value={`${(data?.marketStats.averageDividendYield || 0).toFixed(2)}%`}
                color="blue"
              />
              <StatCard
                label="Volume"
                value={formatLargeNumber(data?.marketStats.totalVolume || 0)}
                color="blue"
              />
            </>
          )}
        </div>

        {/* Market Breadth */}
        {!isLoading && data && (
          <div className="bg-blue-50 rounded-lg p-4">
            <p className="text-sm font-medium text-blue-900 mb-2">
              Sentiment du marché
            </p>
            <div className="flex gap-4 text-sm">
              <span className="text-emerald-600 font-medium">
                ↑ {data.marketStats.advancers} hausses
              </span>
              <span className="text-red-600 font-medium">
                ↓ {data.marketStats.decliners} baisses
              </span>
            </div>
          </div>
        )}

        {/* Sectors Chart */}
        <div>
          <h4 className="text-sm font-semibold mb-3">Répartition sectorielle</h4>
          {isLoading ? (
            <Skeleton className="h-48" />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart
                data={data?.sectors}
                layout="vertical"
                margin={{ left: 80, right: 20 }}
              >
                <XAxis type="number" domain={[0, "auto"]} tickFormatter={(v) => `${v}%`} />
                <YAxis type="category" dataKey="name" width={80} tick={{ fontSize: 12 }} />
                <Tooltip
                  formatter={(value: number) => [`${value.toFixed(1)}%`, "Part"]}
                  contentStyle={{ borderRadius: 8 }}
                />
                <Bar dataKey="weight" radius={[0, 4, 4, 0]}>
                  {data?.sectors.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.change >= 0 ? "#2563eb" : "#3b82f6"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Top Movers */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-semibold text-emerald-700 mb-2">
              Top Hausses
            </h4>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-8" />
                <Skeleton className="h-8" />
                <Skeleton className="h-8" />
              </div>
            ) : (
              <div className="space-y-1">
                {data?.topGainers.slice(0, 3).map((stock) => (
                  <div
                    key={stock.symbol}
                    className="flex justify-between items-center text-sm bg-emerald-50 px-2 py-1 rounded"
                  >
                    <span className="font-medium truncate">{stock.symbol}</span>
                    <span className="text-emerald-600 font-semibold">
                      {formatPercent(stock.changePercent)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div>
            <h4 className="text-sm font-semibold text-red-700 mb-2">Top Baisses</h4>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-8" />
                <Skeleton className="h-8" />
                <Skeleton className="h-8" />
              </div>
            ) : (
              <div className="space-y-1">
                {data?.topLosers.slice(0, 3).map((stock) => (
                  <div
                    key={stock.symbol}
                    className="flex justify-between items-center text-sm bg-red-50 px-2 py-1 rounded"
                  >
                    <span className="font-medium truncate">{stock.symbol}</span>
                    <span className="text-red-600 font-semibold">
                      {formatPercent(stock.changePercent)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Last Updated */}
        {!isLoading && data && (
          <p className="text-xs text-muted-foreground text-center">
            Dernière mise à jour:{" "}
            {new Date(data.index.lastUpdated).toLocaleTimeString("fr-FR")}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function StatCard({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: "blue" | "amber";
}) {
  const bgColor = color === "blue" ? "bg-blue-100" : "bg-amber-100";
  const textColor = color === "blue" ? "text-blue-900" : "text-amber-900";

  return (
    <div className={`${bgColor} rounded-lg p-3`}>
      <p className={`text-xs ${textColor} opacity-80`}>{label}</p>
      <p className={`text-lg font-bold ${textColor}`}>{value}</p>
    </div>
  );
}
