"use client";

import { useEuropeanMarket, useBRVMMarket } from "@/hooks/use-market-data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface ComparisonMetric {
  label: string;
  europe: string | number;
  brvm: string | number;
  europeNote?: string;
  brvmNote?: string;
  winner?: "europe" | "brvm" | "neutral";
}

export function ComparisonTable() {
  const { data: europeData, isLoading: europeLoading } = useEuropeanMarket();
  const { data: brvmData, isLoading: brvmLoading } = useBRVMMarket();

  const isLoading = europeLoading || brvmLoading;

  const formatLarge = (num: number): string => {
    if (num >= 1e12) return `${(num / 1e12).toFixed(1)}T`;
    if (num >= 1e9) return `${(num / 1e9).toFixed(1)}B`;
    if (num >= 1e6) return `${(num / 1e6).toFixed(1)}M`;
    return num.toFixed(0);
  };

  const metrics: ComparisonMetric[] = isLoading
    ? []
    : [
        {
          label: "Capitalisation boursière",
          europe: `€${formatLarge(europeData?.marketStats.totalMarketCap || 0)}`,
          brvm: `€${formatLarge((brvmData?.marketStats.totalMarketCap || 0) / 655.957)}`,
          europeNote: "Marchés développés",
          brvmNote: "Marché émergent",
          winner: "europe",
        },
        {
          label: "Rendement dividendes",
          europe: `${(europeData?.marketStats.averageDividendYield || 0).toFixed(2)}%`,
          brvm: `${(brvmData?.marketStats.averageDividendYield || 0).toFixed(2)}%`,
          winner:
            (brvmData?.marketStats.averageDividendYield || 0) >
            (europeData?.marketStats.averageDividendYield || 0)
              ? "brvm"
              : "europe",
        },
        {
          label: "Ratio P/E moyen",
          europe: (europeData?.marketStats.averagePE || 0).toFixed(1),
          brvm: (brvmData?.marketStats.averagePE || 0).toFixed(1),
          europeNote: "Plus cher",
          brvmNote: "Moins cher",
          winner:
            (brvmData?.marketStats.averagePE || 0) <
            (europeData?.marketStats.averagePE || 0)
              ? "brvm"
              : "europe",
        },
        {
          label: "Performance YTD",
          europe: `${(europeData?.index.ytdReturn || 0).toFixed(1)}%`,
          brvm: `${(brvmData?.index.ytdReturn || 0).toFixed(1)}%`,
          winner:
            (brvmData?.index.ytdReturn || 0) > (europeData?.index.ytdReturn || 0)
              ? "brvm"
              : "europe",
        },
        {
          label: "Devise",
          europe: "EUR (€)",
          brvm: "FCFA (XOF)",
          europeNote: "Devise fluctuante",
          brvmNote: "Arrimé à l'Euro",
          winner: "neutral",
        },
        {
          label: "Investissement minimum",
          europe: "~50€",
          brvm: "~5 000 FCFA (~8€)",
          winner: "brvm",
        },
        {
          label: "Frais de courtage",
          europe: "0.1% - 0.5%",
          brvm: "1% - 2%",
          winner: "europe",
        },
        {
          label: "Liquidité",
          europe: "Très élevée",
          brvm: "Limitée",
          winner: "europe",
        },
        {
          label: "Potentiel de croissance",
          europe: "Modéré",
          brvm: "Élevé",
          europeNote: "Économies matures",
          brvmNote: "Économies en développement",
          winner: "brvm",
        },
        {
          label: "Régulation",
          europe: "Stricte (ESMA)",
          brvm: "Régionale (CREPMF)",
          winner: "europe",
        },
      ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span>Comparaison directe</span>
          <span className="text-sm font-normal text-muted-foreground">
            (données en temps réel)
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(8)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2 font-medium text-muted-foreground">
                    Critère
                  </th>
                  <th className="text-center py-3 px-2 font-medium text-blue-600">
                    <div className="flex items-center justify-center gap-2">
                      <span>🇪🇺</span>
                      <span>Europe</span>
                    </div>
                  </th>
                  <th className="text-center py-3 px-2 font-medium text-amber-600">
                    <div className="flex items-center justify-center gap-2">
                      <span>🌍</span>
                      <span>BRVM</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {metrics.map((metric, index) => (
                  <tr
                    key={metric.label}
                    className={index % 2 === 0 ? "bg-muted/30" : ""}
                  >
                    <td className="py-3 px-2 font-medium">{metric.label}</td>
                    <td
                      className={`py-3 px-2 text-center ${
                        metric.winner === "europe"
                          ? "bg-blue-50 text-blue-700 font-semibold"
                          : ""
                      }`}
                    >
                      <div>{metric.europe}</div>
                      {metric.europeNote && (
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {metric.europeNote}
                        </div>
                      )}
                    </td>
                    <td
                      className={`py-3 px-2 text-center ${
                        metric.winner === "brvm"
                          ? "bg-amber-50 text-amber-700 font-semibold"
                          : ""
                      }`}
                    >
                      <div>{metric.brvm}</div>
                      {metric.brvmNote && (
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {metric.brvmNote}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
