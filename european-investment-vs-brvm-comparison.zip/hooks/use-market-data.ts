"use client";

import useSWR from "swr";
import type { MarketSummary } from "@/lib/market-data";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export function useEuropeanMarket() {
  const { data, error, isLoading, mutate } = useSWR<MarketSummary>(
    "/api/markets/europe",
    fetcher,
    {
      refreshInterval: 60000, // Refresh every minute
      revalidateOnFocus: true,
    }
  );

  return {
    data,
    isLoading,
    isError: error,
    refresh: mutate,
  };
}

export function useBRVMMarket() {
  const { data, error, isLoading, mutate } = useSWR<MarketSummary>(
    "/api/markets/brvm",
    fetcher,
    {
      refreshInterval: 60000, // Refresh every minute
      revalidateOnFocus: true,
    }
  );

  return {
    data,
    isLoading,
    isError: error,
    refresh: mutate,
  };
}
